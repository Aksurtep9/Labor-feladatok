namespace WinFormExpl
{
    public partial class MainForm_JP5JDU : Form
    {

        FileInfo loadedFile = null;
        int counter;
        readonly int counterInitialValue;

        public MainForm_JP5JDU()
        {
            InitializeComponent();
            counterInitialValue = 50;
        }

        private void MainForm_JP5JDU_Load(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close(); 

        }

        private void miOpen_Click(object sender, EventArgs e)
        {
            InputDialog dlg = new InputDialog();


            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string result = dlg.Path;
                listView1.Items.Clear(); try
                {
                    DirectoryInfo di = new DirectoryInfo(result);
                    foreach ( FileInfo fi in di.GetFiles())
                        //Bet�lt�ttem a Subitem-be a F�jl nev�t, m�ret�t �s a f�jl hely�t
                        listView1.Items.Add(new ListViewItem(new string[] { fi.Name, 
                            fi.Length.ToString(),fi.FullName 
                        }));
                    
                }
                catch { }

                  
                }
            }

        //A Labeleket ez t�lti fel a k�rt inform�ci�val
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count != 1) return;

            ListViewItem selected = listView1.SelectedItems[0];

            lName.Text = selected.SubItems[0].Text;

            lCreated.Text = File.GetCreationTime(selected.SubItems[2].Text).ToString();

        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {

                //Az alap �rt�kre �ll�tja
                counter = counterInitialValue;

                //Filepath amit a SubItems[2]-ben t�roltunk
                string filepath = listView1.SelectedItems[0].SubItems[2].Text;

                //F�jl tartalm�t �rja ki
                tContent.Text = System.IO.File.ReadAllText(filepath);

                //loadedFilet egyenl�v� tessz�k vele
                loadedFile = new FileInfo(filepath);

                //Elind�tja a reloadTimert
                reloadTimer.Start();

            }
            catch { }
        }

        //Tick hat�s�ra t�rt�n� v�ltoz�sok
        private void reloadTimer_Tick(object sender, EventArgs e)
        {
            //A sz�ml�l�t cs�kkentj�k
            counter--;

            //Kiv�ltja a paint esem�nyt
            detailsPanel.Invalidate();

            //Ha lej�r, countert �jra alaphelyzetbe �ll�tja �s �jrat�lti a f�jlt
            if (counter <= 0)
            {
                counter = counterInitialValue;
                tContent.Text = File.ReadAllText(loadedFile.FullName);
            }

        }

        //Kirajzol�s
        private void detailsPanel_Paint(object sender, PaintEventArgs e)
        {
            if (loadedFile != null)
            {
                float widht = 120 * counter / counterInitialValue;
                e.Graphics.FillRectangle(Brushes.Brown, 0, 0, widht, 6);
            }
        }

    }
}