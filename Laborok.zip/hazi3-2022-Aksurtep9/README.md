# Szoftvertechnikák 2022 3. házi feladat
A feladat megoldásához a tárgy honlapján található részletes útmutató.
