﻿using System;
using System.Xml.Serialization;
using System.ComponentModel;
using System.IO;

namespace ModernLangToolsApp
{
    public delegate void CouncilChangedDelegate(string message);

    class Program
    {


        [Description("Feladat2")]
        static void Feladat2Test()
        {
            Jedi j = new Jedi
            {
                Name = "Mace", MidiChlorianCount = 500
            };
            XmlSerializer serializer = new XmlSerializer(typeof(Jedi));
            FileStream stream = new FileStream("jedi.txt", FileMode.Create);
            serializer.Serialize(stream, j);
            stream.Close();

            XmlSerializer ser = new XmlSerializer(typeof(Jedi));
            FileStream fs = new FileStream("jedi.txt", FileMode.Open);
            Jedi clone = (Jedi)ser.Deserialize(fs);
            fs.Close();

        }

        [Description("Feladat3")]
        static void Feladat3Test()
        {
            Jedi ObiWan = new Jedi
            {
                Name = "Obi-Wan",
                MidiChlorianCount = 155000
            };

            Jedi SamuelL = new Jedi
            {
                Name = "Mace Windu",
                MidiChlorianCount = 30000
            };

            JediCouncil council = new JediCouncil();
            council.councilChanged += CouncilChanged;

            council.Add(ObiWan);
            council.Add(SamuelL);

            council.Remove();
            council.Remove();
        }

        [Description("Feladat4")]
        static void Feladat4Test()
        {
            Jedi ObiWan = new Jedi
            {
                Name = "Obi-Wan",
                MidiChlorianCount = 100
            };

            Jedi SamuelL = new Jedi
            {
                Name = "Mace Windu",
                MidiChlorianCount = 3000
            };

            Jedi Noob = new Jedi
            {
                Name = "Noobie",
                MidiChlorianCount = 200
            };

            JediCouncil council = new JediCouncil();
            council.Add(ObiWan);
            council.Add(SamuelL);
            council.Add(Noob);

            foreach (Jedi j in council.LowLevel_Delegate())
            {
               Console.WriteLine(j.Name);
            }
        }
        [Description("Feladat5")]
        static void Feladat5Test()
        {
            Jedi ObiWan = new Jedi
            {
                Name = "Obi-Wan",
                MidiChlorianCount = 100
            };

            Jedi SamuelL = new Jedi
            {
                Name = "Mace Windu",
                MidiChlorianCount = 3000
            };

            Jedi Noob = new Jedi
            {
                Name = "Noobie",
                MidiChlorianCount = 200
            };

            JediCouncil council = new JediCouncil();
            council.Add(ObiWan);
            council.Add(SamuelL);
            council.Add(Noob);  

            foreach (Jedi j in council.MidLevel_Lambda())
            {
                Console.WriteLine(j.Name);
            }
        }



        static void CouncilChanged(string message)
        {
            Console.WriteLine("A tanácsban változás történt: " + message);
        }


        static void Main(string[] args)
        {
            Feladat2Test();

            Feladat3Test();

            Feladat4Test();

            Feladat5Test();
            
        }
    }
}
