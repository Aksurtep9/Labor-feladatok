﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ModernLangToolsApp
{
    class JediCouncil
    {
        //Ez a delegateünk
        public event CouncilChangedDelegate councilChanged;

        //public delegate bool JediCountFilter(Jedi a);

        List<Jedi> members = new List<Jedi>();

        //Hatos feladat próbálkozás
        /*public int Count
        {
            get { return CountIf(); }
        }
        */

        //A listához adó függvény
        public void Add(Jedi newJedi)
        {
            members.Add(newJedi);

            //Az invoke az eseményünk miatt kell
            councilChanged?.Invoke($"{ newJedi.Name} joined");
        }
        public void Remove()
        {
            // Eltávolítja a lista utolsó elemét
            members.RemoveAt(members.Count - 1);

            //Ha törlünk ez az event
            councilChanged?.Invoke("Zavart erzek az eroben");
            //Ha elfogyott ez
            if (members.Count == 0)
            {
                councilChanged?.Invoke("A tanacs elesett!");
            }
        }


        public List<Jedi> MidLevel_Lambda()
        {
            return members.FindAll(j => j.MidiChlorianCount < 1000);
        }

        public List<Jedi> LowLevel_Delegate()
        {
            return members.FindAll(JediFilter);
        }

        static bool JediFilter(Jedi J)
        {
            return J.MidiChlorianCount < 600;
        }

        public int Countif(Func<Jedi,bool> filter)
        {
            int count = 0;
            foreach (Jedi j in members)
            {
                if (filter(j))
                {
                    count++;
                }
            }
            return count;
        }

        
            
       


    }
}
