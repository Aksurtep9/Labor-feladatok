﻿using System;
using System.Xml.Serialization;

[XmlRoot("Jedi")]
public class Jedi
{
	
	private string name;
	private int midiChlorianCount;


	[XmlAttribute("MidiChlorianSzam")]
	public int MidiChlorianCount
	{
		get { return midiChlorianCount; }
		set
		{
			if (value < 30)
				throw new ArgumentException("You are not a true jedi!");
			midiChlorianCount = value;
		}
	}

	[XmlAttribute("Nev")]
	public string Name { get { return name; } set { name = value; } }

}
