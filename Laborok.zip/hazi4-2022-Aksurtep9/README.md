﻿# Szoftvertechnikák 2022 4. házi feladat
A feladat megoldásához a tárgy honlapján található részletes útmutató.
