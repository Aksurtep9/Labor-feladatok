namespace MultiThreadedApp
{


    public partial class MainForm_JP5JDU : Form
    {

        private static readonly EventWaitHandle Step1 = new ManualResetEvent(false);
        private static readonly EventWaitHandle Step2 = new AutoResetEvent(false);
        long distance;
        int start;
        private readonly object _lock = new object();

        public MainForm_JP5JDU()
        {
            InitializeComponent();
            distance = 0;
            start = bBike1.Left;
        }

        //Delegate 
        delegate void BikeAction(Button bike);
        Random random = new Random();

        //Mozgat�
        public void MoveBike(Button bike)
        {
            if (InvokeRequired)
            {
                Invoke(new BikeAction(MoveBike), bike);
            }
            else
            {
                int ran = random.Next(3, 9);
                
                increasePixels(ran);
                bike.Left += ran;
                //bike.Left += random.Next(3, 9);
            }
        }

        //A sz�lbiztoss�g miatt kell a lock
        long getPixels()
        {
            lock (_lock)
            {
                return distance;
            }
        }

        //Ki�rja a gombra a t�vols�got
        private void bDistance_Click(object sender, EventArgs e)
        {
            bDistance.Text = distance.ToString();
        }

        //Elind�t� gomb
        private void bStart_Click(object sender, EventArgs e)
        {
            startBike(bBike1);
            startBike(bBike2);
            startBike(bBike3);

        }

        //A Thread seg�df�ggv�nye
        public void BikeThreadFunction(object param)
        {

            Button bike = (Button)param;

            try
            {

                while (bike.Left < pStart.Left)
                {
                    MoveBike(bike);
                    Thread.Sleep(100);
                }

                if (Step1.WaitOne())
                {
                    while(bike.Left < pPihi.Left)
                    {
                        MoveBike(bike);
                        Thread.Sleep(100);
                    }
                }
                if (Step2.WaitOne())
                {
                    while(bike.Left < pTarget.Left)
                    {
                        MoveBike(bike);
                        Thread.Sleep(100);
                    }
                }
            }
            catch (ThreadInterruptedException) { };
        }

        //Start gomb
        private void startBike(Button bBike)
        {
            Thread t = new Thread(BikeThreadFunction);
            bBike.Tag = t;
            t.IsBackground = true;
            t.Start(bBike);
        }

        private void MainForm_JP5JDU_Load(object sender, EventArgs e)
        {

        }

        //A Step1 kattint�s kezel�je: A ManualResetEventet true-ra �ll�tja, majd a viselked�se miatt addig nem �ll vissza am�g Resetet nem kap
        private void bStep1_Click(object sender, EventArgs e)
        {
            if(bBike1.Left >= pStart.Left && bBike2.Left >= pStart.Left && bBike3.Left >= pStart.Left)
            {
                Step1.Set();
            }
        }

        //A Step2 kattint�s kezel�je, Az AutoResetEventet true-ra �ll�tja, majd a viselked�se miatt mag�t�l Reseteli az �rt�ket
        private void bStep2_Click(object sender, EventArgs e)
        {
            if (bBike1.Left >= pPihi.Left && bBike2.Left >= pPihi.Left && bBike3.Left >= pPihi.Left)
            {
                Step2.Set();
            }
        }

        //Increase f�ggv�ny, n�veli a distancet
        void increasePixels(long step)
        {
            lock (_lock)
            {
                distance += step;
            }
        }

        /*private void bike_Click(object sender, EventArgs e)
        {
            Button bike = (Button)sender;
            Thread thread = (Thread)bike.Tag;

            if (thread == null) return;

            thread.Interrupt();

            thread.Join();
            Step1.Reset();

            bike.Left = start;
        }*/

        //Klikkel�s hat�s�ra visszat�r az elej�re
        private void bike_Click(object sender, MouseEventArgs e)
        {
            Button bike = (Button)sender;
            Thread thread = (Thread)bike.Tag;

            if (thread == null) return;

            thread.Interrupt();

            thread.Join();
            //A ManualResetEvent-t Resetelni kell, mert true volt a legutols� �rt�ke
            Step1.Reset();

            //A start pontra �ll�tva
            bike.Left = start;
        }
    }
    }