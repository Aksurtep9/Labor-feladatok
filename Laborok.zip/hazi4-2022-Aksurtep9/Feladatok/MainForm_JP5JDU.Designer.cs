﻿namespace MultiThreadedApp
{
    partial class MainForm_JP5JDU
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bBike1 = new System.Windows.Forms.Button();
            this.bStart = new System.Windows.Forms.Button();
            this.pTarget = new System.Windows.Forms.Panel();
            this.bStep1 = new System.Windows.Forms.Button();
            this.pStart = new System.Windows.Forms.Panel();
            this.bBike2 = new System.Windows.Forms.Button();
            this.bBike3 = new System.Windows.Forms.Button();
            this.pPihi = new System.Windows.Forms.Panel();
            this.bStep2 = new System.Windows.Forms.Button();
            this.bDistance = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bBike1
            // 
            this.bBike1.Font = new System.Drawing.Font("Webdings", 32F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bBike1.Location = new System.Drawing.Point(32, 53);
            this.bBike1.Name = "bBike1";
            this.bBike1.Size = new System.Drawing.Size(147, 110);
            this.bBike1.TabIndex = 0;
            this.bBike1.Text = "b";
            this.bBike1.UseVisualStyleBackColor = true;
            this.bBike1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.bike_Click);
            // 
            // bStart
            // 
            this.bStart.Location = new System.Drawing.Point(32, 412);
            this.bStart.Name = "bStart";
            this.bStart.Size = new System.Drawing.Size(147, 97);
            this.bStart.TabIndex = 1;
            this.bStart.Text = "Start";
            this.bStart.UseVisualStyleBackColor = true;
            this.bStart.Click += new System.EventHandler(this.bStart_Click);
            // 
            // pTarget
            // 
            this.pTarget.BackColor = System.Drawing.Color.LightSteelBlue;
            this.pTarget.Location = new System.Drawing.Point(786, 43);
            this.pTarget.Name = "pTarget";
            this.pTarget.Size = new System.Drawing.Size(199, 366);
            this.pTarget.TabIndex = 2;
            // 
            // bStep1
            // 
            this.bStep1.Location = new System.Drawing.Point(262, 420);
            this.bStep1.Name = "bStep1";
            this.bStep1.Size = new System.Drawing.Size(166, 89);
            this.bStep1.TabIndex = 3;
            this.bStep1.Text = "Step1";
            this.bStep1.UseVisualStyleBackColor = true;
            this.bStep1.Click += new System.EventHandler(this.bStep1_Click);
            // 
            // pStart
            // 
            this.pStart.BackColor = System.Drawing.Color.LightSlateGray;
            this.pStart.Location = new System.Drawing.Point(262, 53);
            this.pStart.Name = "pStart";
            this.pStart.Size = new System.Drawing.Size(166, 355);
            this.pStart.TabIndex = 4;
            // 
            // bBike2
            // 
            this.bBike2.Font = new System.Drawing.Font("Webdings", 32F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bBike2.Location = new System.Drawing.Point(32, 169);
            this.bBike2.Name = "bBike2";
            this.bBike2.Size = new System.Drawing.Size(147, 110);
            this.bBike2.TabIndex = 5;
            this.bBike2.Text = "b";
            this.bBike2.UseVisualStyleBackColor = true;
            this.bBike2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.bike_Click);
            // 
            // bBike3
            // 
            this.bBike3.Font = new System.Drawing.Font("Webdings", 32F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bBike3.Location = new System.Drawing.Point(32, 285);
            this.bBike3.Name = "bBike3";
            this.bBike3.Size = new System.Drawing.Size(147, 110);
            this.bBike3.TabIndex = 6;
            this.bBike3.Text = "b";
            this.bBike3.UseVisualStyleBackColor = true;
            this.bBike3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.bike_Click);
            // 
            // pPihi
            // 
            this.pPihi.BackColor = System.Drawing.Color.Cyan;
            this.pPihi.Location = new System.Drawing.Point(514, 53);
            this.pPihi.Name = "pPihi";
            this.pPihi.Size = new System.Drawing.Size(172, 355);
            this.pPihi.TabIndex = 7;
            // 
            // bStep2
            // 
            this.bStep2.Location = new System.Drawing.Point(514, 420);
            this.bStep2.Name = "bStep2";
            this.bStep2.Size = new System.Drawing.Size(172, 89);
            this.bStep2.TabIndex = 8;
            this.bStep2.Text = "Step2";
            this.bStep2.UseVisualStyleBackColor = true;
            this.bStep2.Click += new System.EventHandler(this.bStep2_Click);
            // 
            // bDistance
            // 
            this.bDistance.Location = new System.Drawing.Point(791, 432);
            this.bDistance.Name = "bDistance";
            this.bDistance.Size = new System.Drawing.Size(194, 73);
            this.bDistance.TabIndex = 9;
            this.bDistance.UseVisualStyleBackColor = true;
            this.bDistance.Click += new System.EventHandler(this.bDistance_Click);
            // 
            // MainForm_JP5JDU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 545);
            this.Controls.Add(this.bDistance);
            this.Controls.Add(this.bStep2);
            this.Controls.Add(this.bBike3);
            this.Controls.Add(this.bBike2);
            this.Controls.Add(this.bStep1);
            this.Controls.Add(this.bStart);
            this.Controls.Add(this.bBike1);
            this.Controls.Add(this.pTarget);
            this.Controls.Add(this.pStart);
            this.Controls.Add(this.pPihi);
            this.Name = "MainForm_JP5JDU";
            this.Text = "Tour de France - JP5JDU";
            this.Load += new System.EventHandler(this.MainForm_JP5JDU_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Button bBike1;
        private Button bStart;
        private Panel pTarget;
        private Button bStep1;
        private Panel pStart;
        private Button bBike2;
        private Button bBike3;
        private Panel pPihi;
        private Button bStep2;
        private Button bDistance;
    }
}