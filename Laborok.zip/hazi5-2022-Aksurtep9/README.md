﻿# Szoftvertechnikák 2022 5. házi feladat
A feladat megoldásához a tárgy honlapján található részletes útmutató.
