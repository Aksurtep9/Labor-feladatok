﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Signals
{
    public class SignalDocument : Document
    {

        List<SignalValue> signals = new List<SignalValue>();

        private SignalValue[] testValues = new SignalValue[]
        {
           new SignalValue(6, new DateTime(2022, 2, 2, 2, 0, 0, 111)),
           new SignalValue(7, new DateTime(2022, 2, 2, 4, 0, 1, 876)),
           new SignalValue(-1, new DateTime(2022, 2, 2, 6, 0, 2, 300)),
           new SignalValue(2, new DateTime(2022, 2, 2, 10, 0, 3, 232)),
           new SignalValue(-5, new DateTime(2022, 2, 2, 15, 0, 5, 885)),
           new SignalValue(-15, new DateTime(2022, 2, 2, 20, 0, 6, 125))
        };

        public IReadOnlyList<SignalValue> Signals
        {
            get { return signals; }
        }


        public SignalDocument(string name) : base(name)
        {
            signals.AddRange(testValues);
        }

        public override void SaveDocument(string filePath)
        {
            using (StreamWriter sw = new StreamWriter(filePath))
            {
                foreach(SignalValue signal in signals)
                {
                    string dt = signal.GetTimeStamp().ToUniversalTime().ToString("o");

                    sw.WriteLine(signal.GetValue() + "\t" + dt);
                }

                sw.Close();
            }
        }

        public override void LoadDocument(string filePath)
        {
            signals.Clear();

            using (StreamReader sr = new StreamReader(filePath))
            {
                String line;

                while ((line = sr.ReadLine()) != null)
                {
                    // A line változóban benne van az aktuális sor

                    line = line.Trim();
                    string[] columns = line.Split("\t");

                    double d = Double.Parse(columns[0]);
                    DateTime dt = DateTime.Parse(columns[1]);

                    DateTime localDt = dt.ToLocalTime();

                    signals.Add(new SignalValue(d, localDt));
                }

                sr.Close();
                
            }

            TraceValues();
            UpdateAllViews();
        }

        void TraceValues()
        {
            foreach (SignalValue signal in signals)
                Trace.WriteLine(signal.ToString());
        }


    }
}
