﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Signals
{
    public partial class GraphicsSignalView : UserControl , IView
    {

        //A SignalDocument tagváltozó
        private SignalDocument document;


        private int viewNumber;

        double pixelPerSec = 0.007;
        
        private int pixelPerValue = 10;

        private double scale = 1;


        //Paraméteres konstruktor
        public GraphicsSignalView(SignalDocument document)
        {
            InitializeComponent();
            this.document = document;
        }

        public int ViewNumber { get => viewNumber; set => viewNumber = value; }

        public Document GetDocument()
        {
            return document;
        }


        protected override void OnPaint(PaintEventArgs e)
        {

            //Ős OnPaint meghívása
            base.OnPaint(e);

            //Piros 2 pixel széles toll
            Pen pen = new Pen(Color.Red, 2);

            //Szaggatott
            pen.DashStyle = DashStyle.Dot;

            //Nyíl a vége
            pen.EndCap = LineCap.ArrowAnchor;


            //Függőleges tengely, ahogy a leírás írta a második pixeltől kezdve
            e.Graphics.DrawLine(pen, new Point(2, 0), new Point(2, ClientSize.Height));

            //Vízszintes tengely (itt fölösleges a második pixeltől(?))
            e.Graphics.DrawLine(pen, new Point(0, ClientSize.Height / 2), new Point(ClientSize.Width, ClientSize.Height / 2));

            //A koordináta tengely elejéről indul
            double prevX = 3;
            double prevY = 3;

            double x = prevX;
            double y = prevY;

            //A vonal beállítása kékre, 2pixel vastag, folytonos, nyíl nélküli
            pen = new Pen(Color.Blue, 2);
            pen.DashStyle = DashStyle.Solid;
            pen.EndCap = LineCap.Flat;

            SignalValue prevSignal = null;
            
            //Végigmegyünk a Signals-on
            foreach (SignalValue signal in document.Signals)
            {

                y = (-1*signal.GetValue()*pixelPerValue * scale + ClientSize.Height/2);

                if (prevSignal != null)
                {
                    TimeSpan t = signal.GetTimeStamp() - prevSignal.GetTimeStamp();

                    // 1 Tick = 100 ns és ezt szorozzuk a pixel/seccel
                    x += t.Ticks / 10000000 * pixelPerSec * scale;
                }

                //Az értékek kirajzolása
                e.Graphics.FillRectangle(new SolidBrush(Color.Blue), new Rectangle((int)x, (int)y, 3, 3));


                //Az értékek összekötése
                if(prevSignal != null)
                {
                    e.Graphics.DrawLine(pen, new Point((int)prevX, (int)prevY), new Point((int)x, (int)y));
                }

                //Az értékek állítása, hogy a következő iterációban ezek lehessenek a kiindulópontok
                prevSignal = signal;

                prevX = x;
                prevY = y;

            }
        }

        private void zoomIn_Click(object sender, EventArgs e)
        {
            //A scalet növeljük, majd újrarajzoljuk
            scale = scale*1.2;
            Invalidate();
        }

        private void GraphicsSignalView_Load(object sender, EventArgs e)
        {

        }

        private void zoomOut_Click(object sender, EventArgs e)
        {
            //A scalet csökkentjük, majd újrarajzoljuk
            scale = scale / 1.2;
            Invalidate();
        }
    }
}
