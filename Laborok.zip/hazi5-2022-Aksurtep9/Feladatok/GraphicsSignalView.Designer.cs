﻿namespace Signals
{
    partial class GraphicsSignalView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;



        

        //public int ViewNumber { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }


        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.zoomIn = new System.Windows.Forms.Button();
            this.zoomOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // zoomIn
            // 
            this.zoomIn.Location = new System.Drawing.Point(15, 19);
            this.zoomIn.Name = "zoomIn";
            this.zoomIn.Size = new System.Drawing.Size(29, 28);
            this.zoomIn.TabIndex = 0;
            this.zoomIn.Text = "+";
            this.zoomIn.UseVisualStyleBackColor = true;
            this.zoomIn.Click += new System.EventHandler(this.zoomIn_Click);
            // 
            // zoomOut
            // 
            this.zoomOut.Location = new System.Drawing.Point(50, 19);
            this.zoomOut.Name = "zoomOut";
            this.zoomOut.Size = new System.Drawing.Size(30, 28);
            this.zoomOut.TabIndex = 1;
            this.zoomOut.Text = "-";
            this.zoomOut.UseVisualStyleBackColor = true;
            this.zoomOut.Click += new System.EventHandler(this.zoomOut_Click);
            // 
            // GraphicsSignalView
            // 
            this.Controls.Add(this.zoomOut);
            this.Controls.Add(this.zoomIn);
            this.Name = "GraphicsSignalView";
            this.Size = new System.Drawing.Size(442, 325);
            this.ResumeLayout(false);

        }

        private Button zoomIn;
        private Button zoomOut;

        #endregion
        /*
        private Button zoomOut;
        private Button zoomIn;
        */
    }
}
