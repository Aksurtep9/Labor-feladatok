﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Signals
{
    public class SignalValue
    {
        readonly double Value;

        readonly DateTime TimeStamp;

        public SignalValue(double value, DateTime timeStamp)
        {
            Value = value;
            TimeStamp = timeStamp;
        }

        public double GetValue()
        {
            return Value;
        }

        public DateTime GetTimeStamp()
        {
             return TimeStamp;
        }

        public override string ToString()
        {
            return string.Format("Value: {0}, TimeStamp: {1}", Value, TimeStamp);
        }
    }
}
